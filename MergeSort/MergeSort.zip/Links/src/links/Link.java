/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package links;

/**
 *
 * @author fac_peterson
 */
public class Link<T> {

    public Link<T> next;
    public T data;

    public Link(T data, Link<T> next) {
        this.data = data;
        this.next = next;
    }

    public String toString() {
        return print(this);
    }

    
    public static <T> String print(Link<T> x) {
        return "[" + print1(x);
    }

    public static <T> String print1(Link<T> x) {
        if (x == null) {
            return "]";
        }
        if (x.next == null) {
            return x.data + "]";
        }
        return x.data + ", " + print1(x.next);
    }
}
